points_x = 1024; 

% ex1(); 

% compressFunction(points_x, 8, 'Haar', 'Doppler', 0.92); 

% plotErrorCompression(points_x, 5, 'Battle', 'Doppler'); 
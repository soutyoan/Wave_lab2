# Lab 2 : 1D Orthogonal Wavelet Transform
Yoan SOUTY
Antonin KLOPP-TOSSER

# Lancer les programmes

Toutes les fonctions pouvant être utilisées sont dans le fichier lab2.m

 - ex1() : permet de lancer le graphe des fonctions de l'exercice 1. Il est possible de changer les paramètres à l'intérieur du fichier ex1.m

 - compressFunction(points_x, points_y, family, dataset, taux_compression) : permet d'afficher le graphe d'une fonction compressée et décompressé.

 - plotErrorCompression(points_x, points_y, family, dataset) : permet d'afficher la courbe loglog de l'erreur en fonction du taux de compression. 
